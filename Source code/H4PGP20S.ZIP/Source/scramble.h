/*********************************************************************
  Header-file for the scramble module of Hide4PGP by Heinz Repp
  last modified: 11/28/99
*********************************************************************/

UBYTE Scramble (UBYTE);
UBYTE DeScramble (UBYTE);
void ResetScrambler (void);
